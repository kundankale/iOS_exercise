import UIKit


//Write a Swift program to create a new string where all the character "a" have been removed except the first and last positions

var inputString :String
inputString = "Kundankale a b"
var length = inputString.count

print(length)

var outString : String = ""

for (index, element) in inputString.enumerated() {
    print("Index: \(index), Element: \(element)")
    
    if(index == 0 || index == length-1){
        outString = outString + element.description
    
    }else if(element != "a"){
        outString = outString + element.description
    }
}
print(outString)

//Write a Swift program to create a Swift program to count the number of 7's in a given array of integers.

var inputArray :[Int] = [3,5,7,9]
var numberToCheck = 7
var count = 0

for n in inputArray {
    
    if n == numberToCheck {
        count  = count + 1
    }
}
print ("total count is \(count)")

//How do you check if two strings are equal in Swift?
var firstString  = "Kundan"
var SecondString = "Kundan"
if(firstString.elementsEqual(SecondString)){
    print("Strings matched")
}else{
    print("String not matched")
}

//Create a mutable dictionary named secretIdentities where the key value pairs are "Hulk" -> "Bruce Banner", "Batman" -> "Bruce Wayne", and "Superman" -> "Clark Kent".

var dict1 = ["Hulk": "Bruce Banner", "Batman": "Bruce Wayne" ,  "Superman": "Clark Kent" ]

print(dict1)

//Using if, print "It's too hot" if the temperature is 30 degrees or above. Print "It's too cold" if the temperature is less than 0 degrees. Finally, print "It's tolerable" for any other temperature.

var temp = 30
if(temp>=30){
    print("Its too hot")
}else if(temp < 0){
    print("Its too cold")
}else{
    print("Its tolerable")
}

//Write a Swift program that accept two integer values and return true if one of them is 20 or if their sum is 20.

func calculation(a : Int , b : Int) -> Bool
{
    if a == 20 || b == 20 || (a+b) == 20{
        return true
    }
    return false
}

print("calculation : "  ,calculation(a: 0, b: 20))



//Write a Swift program to compute the sum of the two integers. If the values are equal return the triple their sum.
func calculateSum (a : Int , b : Int) -> Int
{
    if a == b{
        return ((a+b) * 3)
    }
    else{
        return a + b
    }
}

print("sum",calculateSum(a: 10, b: 11))

//Write a Swift program to create a string taking characters at indexes 0, 2, 4, 6, 8, .. from a given string.
let mystr = "kundankale"
let mystrArray = Array(mystr)
let strLength = mystrArray.count
var resultStrArray : [Character] = []
var i = 0

while i < strLength {
    if i % 2 == 0 {
        resultStrArray.append(mystrArray[i])
    }
    i += 1
}
let resultString = String(resultStrArray)
print(resultString)

//Write a Swift program to find the largest number among three given integers. */
func findLargestNumber(a : Int , b : Int , c : Int) -> Int {
    
    if a > b && a > c {
        return a
    }
    else if b > a && b > c {
        return b
    }
    else{
        return c
    }
}

findLargestNumber(a: 100, b: 5, c: 11)


//Write a Swift program that return true if either of two given integers is in the range 10..30 inclusive. */
func checkIntegerInsideRange(a : Int , b : Int) -> Bool {
    
    if (10 ... 30).contains(a) || (10 ... 30).contains(b) {
        return true
    }
    return false
}

checkIntegerInsideRange(a: 200, b: 25)


//Write a Swift program to check if a given non-negative number is a multiple of 3 or a multiple of 5.  */
func checkMultipleNumber( a : Int) -> Int {
    
    if a % 3 == 0 {
        return 3
    }
    else if a % 5 == 0 {
        return 5
    }
    else{
        return 1
    }
}
var num = 15
print("number \(num) is a multiple of ",checkMultipleNumber(a: num))





// ------- function examples -------------------

//Write a function named countdown that takes a number N. The function should print the numbers from N to 1 with a one second pause in between and then write GO! in the end. To make the computer wait for one second call thesleep function from the standard library. The sleep function takes one parameter, the number of seconds to sleep.

func countdownTimer ( number : Int){
    var loopNUmber = number
    print(loopNUmber)
    while(loopNUmber>1){
        
        sleep(1)
        
        print("Go..!")
     
         loopNUmber -=  1
    }
    
}

countdownTimer( number: 5)

//Write a function named timeDifference. It takes as input four numbers that represent two times in a day and returns the difference in minutes between them. The first two parameters firstHour and firstMinute represent the hour and minute of the first time. The last two secondHour and secondMinute represent the hour and minute of the second time. All parameters should have external parameter names with the same name as the local ones.

func timeDifference(firstHour : Int , firstMinute : Int ,secondHour : Int, secondMinute : Int ) -> Int {
    
    let hourDiffrence = firstHour - secondHour
    let minuteDiffrence = firstMinute - secondMinute
    let timeDiffrenceInMinute = (hourDiffrence * 60 ) + minuteDiffrence
    return timeDiffrenceInMinute
}
let firstHour = 4
let firstMinute = 40
let secondHour = 2
let secondMinute = 20

print(timeDifference(firstHour: firstHour, firstMinute: firstMinute, secondHour: secondHour, secondMinute: secondMinute))


//Write a function named parse(digit:) that takes a string with one character as parameter. The function should return -1 if the input is not a digit character and the digit otherwise.


func parse ( digit : String) ->Int{
    
    let convertedValue = Int(digit)
     return convertedValue ?? -1
}

print (parse(digit: "k"))



//Implement a function named repeatPrint that takes a string message and a integer count as parameters. The function should print the message count times and then print a newline.

func repeatPrint(message : String , count : Int) {
    
    var i = 0
    while i < count {
        print("input is " , message + " \n")
        i += 1
    }
}

repeatPrint(message: "HelloWorld", count: 3)

//Write a function sum that takes a variable number of integers as input and returns the sum of the numbers.

func sum(number1 : Int , number2 : Int) -> Int{
    
    return number1 + number2
}
print ( sum(number1: 100, number2: 200) )

//Write a function whoAmI that takes a name as input parameter. If the name is "Bruce Wayne", the function should return "I am Batman", otherwise return "I am not Batman". The input parameter should have a default value of "Bruce Wayne".

func whoAmI(name : String =  "Bruce Wayne")  -> String {
    
    if name == "Bruce Wayne" {
        return "I am Batman"
    }
    else{
        return "I am not Batman"
    }
}
print( whoAmI(name: "B") )

//Write a function square that takes an Int as input, but doesn't require a label at the call site, i.e. square(3) should work. It should return the square of the input value.

func square(_ number : Int) -> Int {
    return number * number
}

print ( square(3) )
//Write a function greet that takes the first name and last name of a person (e.g. "Donald" and "Trump") as two separate input parameters and prints a greeting to that person (e.g. "Hello, Donald Trump!").

func greet (firstName : String , lastName : String) {
    print("Hello, " + firstName + " " +  lastName + "!")
}

greet(firstName: "Donald", lastName: "Trump")

//Write a function greeting that takes the name of a person (e.g. "Donald Trump") as input and returns a greeting string (e.g. "Hello, Donald Trump!") that can be printed.

func greeting(name : String)  -> String {
    return "Hello, " + name + "!"
}
print ( greeting(name: "Donald Trump") )

//Write a function greet that takes the name of a person (e.g. "Donald Trump") as input and prints a greeting to that person (e.g. "Hello, Donald Trump!").

func greet(name : String)  {
    print("Hello, " + name + "!")
}
greet(name: "Donald Trump")

//Write a function named printHelloWorld that takes no arguments and returns nothing. It should print "Hello, World!".

func printHelloWorld(){
    print("Hello, World!")
}
printHelloWorld()
